iraqi.proten — موقع تعريفي عربي

تم تضمين:
- صفحة عربية متجاوبة مع الهاتف.
- رابط واتساب: https://wa.me/9647715599604
- رابط إنستغرام: https://www.instagram.com/iraqi.proten/

النشر المجاني عبر GitHub Pages:
1. أنشئ حساباً في https://github.com
2. أنشئ مستودعاً باسم iraqi-proten.
3. ارفع index.html إلى المستودع.
4. افتح Settings ثم Pages.
5. اختر Deploy from a branch، ثم main و /(root)، واضغط Save.
6. استخدم رابط Pages الذي يظهر بعد النشر.

ملاحظة: الاستضافة المجانية تعتمد على استمرار توفر الخدمة والالتزام بشروطها؛ لا يمكن ضمان أي منصة للأبد.
